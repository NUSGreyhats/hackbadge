#!/bin/sh
./minichlink -w main.bin 0x08000000 -b
